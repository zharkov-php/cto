
<!-- Main Footer -->
<footer class="main-footer" style="background-image: url(images/background/2018-bmw-m5-first-drive.jpg);">
    <div class="auto-container">

        <!--Widgets Section-->

    </div>

    <!--Footer Bottom-->
    <div class="footer-bottom">
        <div class="auto-container">
            <div class="copyright-text">
                <p>Copyrights © 2018 All Rights Reserved. by <a href="#"> Expert Themes</a></p>
            </div>
        </div>
    </div>
</footer>
<!-- End Main Footer -->

</div>
<!--End pagewrapper-->

<!--Scroll to top-->
<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fas fa-car"></span></div>

<!-- Color Palate / Color Switcher -->
<!-- <div class="color-palate">
    <div class="color-trigger">
        <i class="fa fa-cog"></i>
    </div>
    <div class="color-palate-head">
        <h6>Choose Your Colorxxx</h6>
    </div>
    <div class="various-color clearfix">
        <div class="colors-list">
            <span class="palate default-color active" data-theme-file="css/color-themes/default-theme.css"></span>
            <span class="palate green-color" data-theme-file="css/color-themes/green-theme.css"></span>
            <span class="palate yellow-color" data-theme-file="css/color-themes/blue-theme.css"></span>
            <span class="palate orange-color" data-theme-file="css/color-themes/orange-theme.css"></span>
            <span class="palate purple-color" data-theme-file="css/color-themes/purple-theme.css"></span>
            <span class="palate teal-color" data-theme-file="css/color-themes/teal-theme.css"></span>
            <span class="palate brown-color" data-theme-file="css/color-themes/brown-theme.css"></span>
            <span class="palate redd-color" data-theme-file="css/color-themes/redd-color.css"></span>
        </div>
    </div>

    <a href="#" class="purchase-btn">Purchase now $17</a>

    <div class="palate-foo">
        <span>You will find much more options for colors and styling in admin panel. This color picker is used only for demonstation purposes.</span>
    </div> -->


</div>

<script src="/main_template/js/jquery.js"></script>
<script src="/main_template/js/bootstrap.min.js"></script>
<!--Revolution Slider-->
<script src="/main_template/plugins/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script src="/main_template/plugins/revolution/js/jquery.themepunch.tools.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="/main_template/plugins/revolution/js/extensions/revolution.extension.video.min.js"></script>
<script src="/main_template/js/main-slider-script.js"></script>
<!--End Revolution Slider-->
<script src="/main_template/js/jquery-ui.js"></script>
<script src="/main_template/js/jquery.fancybox.js"></script>
<script src="/main_template/js/owl.js"></script>
<script src="/main_template/js/appear.js"></script>
<script src="/main_template/js/wow.js"></script>
<script src="/main_template/js/mixitup.js"></script>
<script src="/main_template/js/script.js"></script>
<!--Google Map APi Key-->
<script src="http://maps.google.com/maps/api/js?key=AIzaSyBKS14AnP3HCIVlUpPKtGp7CbYuMtcXE2o"></script>
<script src="/main_template/js/map-script.js"></script>
<!--End Google Map APi-->
<script src="/main_template/js/color-settings.js"></script>
</body>
</html>