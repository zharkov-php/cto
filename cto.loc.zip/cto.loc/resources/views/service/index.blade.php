@extends('.layouts/main')

@section('content')



    <!-- Services Section -->
    <section class="services-page-section">
        <div class="auto-container">
            <div class="row clearfix">
                <!-- Service Block -->
                <div class="service-block col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure><img src="/main_template/images/resource/service-1.jpg" alt=""></figure>
                            <div class="title"><h4>Ремонт подвески</h4></div>
                        </div>
                        <div class="caption-box">
                            <div class="title-box">
                                <span class="icon flaticon-electrical"></span>
                                <h4><a href="service-detail.html">Ремонт подвески</a></h4>
                            </div>
                            <p>We should point out that maintaining your vehicle with an occasional visual inspectionfluid level.</p>
                        </div>
                    </div>
                </div>

                <!-- Service Block -->
                <div class="service-block col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure><img src="/main_template/images/resource/service-2.jpg" alt=""></figure>
                            <div class="title"><h4>Капитальный ремонт двигателя</h4></div>
                        </div>
                        <div class="caption-box">
                            <div class="title-box">
                                <span class="icon flaticon-pistons"></span>
                                <h4><a href="service-detail.html">Капитальный ремонт двигателя</a></h4>
                            </div>
                            <p>We should point out that maintaining your vehicle with an occasional visual inspectionfluid level.</p>
                        </div>
                    </div>
                </div>

                <!-- Service Block -->
                <div class="service-block col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure><img src="/main_template/images/resource/service-3.jpg" alt=""></figure>
                            <div class="title"><h4>Шото мля... и с колесами делаем)))</h4></div>
                        </div>
                        <div class="caption-box">
                            <div class="title-box">
                                <span class="icon flaticon-cogwheel"></span>
                                <h4><a href="service-detail.html">Wheel Alignment</a></h4>
                            </div>
                            <p>We should point out that maintaining your vehicle with an occasional visual inspectionfluid level.</p>
                        </div>
                    </div>
                </div>

                <!-- Service Block -->
                <div class="service-block col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure><img src="/main_template/images/resource/service-4.jpg" alt=""></figure>
                            <div class="title"><h4>Что то умеем открутить</h4></div>
                        </div>
                        <div class="caption-box">
                            <div class="title-box">
                                <span class="icon flaticon-electrical"></span>
                                <h4><a href="service-detail.html">Suspension Repair</a></h4>
                            </div>
                            <p>We should point out that maintaining your vehicle with an occasional visual inspectionfluid level.</p>
                        </div>
                    </div>
                </div>

                <!-- Service Block -->
                <div class="service-block col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure><img src="/main_template/images/resource/service-5.jpg" alt=""></figure>
                            <div class="title"><h4>Порно смотрим на работе</h4></div>
                        </div>
                        <div class="caption-box">
                            <div class="title-box">
                                <span class="icon flaticon-pistons"></span>
                                <h4><a href="service-detail.html">Порно смотрим на работе</a></h4>
                            </div>
                            <p>We should point out that maintaining your vehicle with an occasional visual inspectionfluid level.</p>
                        </div>
                    </div>
                </div>

                <!-- Service Block -->
                <div class="service-block col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="image-box">
                            <figure><img src="/main_template/images/resource/service-6.jpg" alt=""></figure>
                            <div class="title"><h4>Находим лишние детали</h4></div>
                        </div>
                        <div class="caption-box">
                            <div class="title-box">
                                <span class="icon flaticon-cogwheel"></span>
                                <h4><a href="service-detail.html">Находим лишние детали</a></h4>
                            </div>
                            <p>We should point out that maintaining your vehicle with an occasional visual inspectionfluid level.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Styled Pagination -->
            <div class="styled-pagination text-center clearfix">
                <ul class="clearfix">
                    <li><a href="#" class="active">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a class="next" href="#"><span class="fa fa-angle-right"></span></a></li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Services Section -->


    <!--Clients Section-->
    <section class="clients-section alternate">
        <div class="auto-container">
            <div class="sponsors-outer">
                <!--Sponsors Carousel-->
                <ul class="sponsors-carousel owl-carousel owl-theme">
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/1.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/2.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/3.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/4.png" alt=""></a></figure></li>
                    <li class="slide-item"><figure class="image-box"><a href="#"><img src="images/clients/5.png" alt=""></a></figure></li>
                </ul>
            </div>
        </div>
    </section>
    <!--End Clients Section-->

@endsection