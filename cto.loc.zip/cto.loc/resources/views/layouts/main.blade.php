<!--include Header template-->
@include('.main/header')
<hr>

@yield('content')

<hr>
<!--include Footer template-->
@include('.main/footer')